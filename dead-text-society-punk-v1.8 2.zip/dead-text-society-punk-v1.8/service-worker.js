const CACHE = 'dead-text-society-punk-v1.8-mobile-scroll-fix-1';
const CORE = [
  './','./index.html','./styles.css','./app.js','./config.js','./data/prompts-data.js','./locales.js',
  './assets/paper.webp','./assets/black.webp','./assets/hero.webp','./assets/pattern.webp','./assets/waves.webp','./assets/burst.webp','./assets/skull.webp','./assets/skull-card.webp','./assets/ruins.webp',
  './icons/favicon-32.png','./icons/apple-touch-icon.png','./icons/icon-192.png','./icons/icon-512.png','./icons/icon-maskable-512.png','./manifest.webmanifest',
  './data/prompts.json','./downloads/Dead_Text_Society_Prompt_Master_EN.xlsx','./downloads/dead-text-society-vault.md'
];
self.addEventListener('install',event=>event.waitUntil(caches.open(CACHE).then(cache=>cache.addAll(CORE)).then(()=>self.skipWaiting())));
self.addEventListener('activate',event=>event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',event=>{
  if(event.request.method!=='GET')return;
  event.respondWith(caches.match(event.request).then(cached=>cached||fetch(event.request).then(response=>{
    const copy=response.clone();
    if(new URL(event.request.url).origin===self.location.origin)caches.open(CACHE).then(cache=>cache.put(event.request,copy));
    return response;
  }).catch(()=>event.request.mode==='navigate'?caches.match('./index.html'):Response.error())));
});
