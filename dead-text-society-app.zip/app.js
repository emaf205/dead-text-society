(() => {
  'use strict';

  const config = window.DTS_CONFIG || {};
  const data = window.DTS_DATA?.prompts || [];
  const localeData = window.DTS_LOCALES || {categories:{},prompts:{}};
  const reducedMotion = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;

  const ui = {
    en:{tagline:'Give dead content another life.',search:'SEARCH',categories:'Categories',surprise:'SURPRISE ME',noResults:'No results',noFavorites:'No favorites',try:'TRY THIS',view:'View',copy:'Copy',download:'Download',share:'Share',favorite:'Favorite',unfavorite:'Remove favorite',close:'Close',clear:'Clear',copied:'COPIED',shared:'LINK COPIED',saved:'SAVED',removed:'REMOVED',install:'Install',error:'Unavailable',home:'Home',favorites:'Favorites'},
    it:{tagline:'Dai un’altra vita ai contenuti morti.',search:'CERCA',categories:'Categorie',surprise:'SORPRENDIMI',noResults:'Nessun risultato',noFavorites:'Nessun preferito',try:'PROVA QUESTO',view:'Vedi',copy:'Copia',download:'Scarica',share:'Condividi',favorite:'Preferito',unfavorite:'Rimuovi',close:'Chiudi',clear:'Pulisci',copied:'COPIATO',shared:'LINK COPIATO',saved:'SALVATO',removed:'RIMOSSO',install:'Installa',error:'Non disponibile',home:'Home',favorites:'Preferiti'}
  };

  const categoryShort = {
    en:{'Narrative':'Narrative','Critique':'Critique','Interdisciplinary':'Interdisc.','Systems / Economics':'Systems','Future / Signals':'Future','Psychology / Society':'Psychology','History / Philosophy':'History','Editorial / Formats':'Editorial','Visual / Images':'Visual','Infographics / Maps':'Maps','Video / Audio':'Video','Teaching / Interactive':'Teaching','Research / Theory':'Research','Contrarian / Red Team':'Red Team','JOLLY / Universal':'Jolly'},
    it:{'Narrative':'Narrativa','Critique':'Critica','Interdisciplinary':'Interdisc.','Systems / Economics':'Sistemi','Future / Signals':'Futuro','Psychology / Society':'Psicologia','History / Philosophy':'Storia','Editorial / Formats':'Editoriale','Visual / Images':'Visual','Infographics / Maps':'Mappe','Video / Audio':'Video','Teaching / Interactive':'Didattica','Research / Theory':'Ricerca','Contrarian / Red Team':'Red Team','JOLLY / Universal':'Jolly'}
  };

  const assetFamilies=['hero.webp','skull-card.webp','ruins.webp','waves.webp','burst.webp','pattern.webp','black.webp','paper.webp'];
  function readStorage(key){ try{return localStorage.getItem(key);}catch{return null;} }
  function writeStorage(key,value){ try{localStorage.setItem(key,value);return true;}catch{return false;} }
  let lang = readStorage('dts-lang') === 'it' ? 'it' : 'en';
  let mode = 'home'; // home | search | category | favorites
  let category = null;
  let homePicks = [];
  let current = null;
  let lastFocus = null;
  let installEvent = null;
  let favorites = loadFavorites();

  const $ = s => document.querySelector(s);
  const $$ = s => [...document.querySelectorAll(s)];
  const els = {
    list:$('#promptList'), results:$('#resultsSection'), search:$('#searchInput'), clear:$('#clearSearch'), home:$('#homeBtn'), brandHome:$('#brandHomeBtn'),
    categories:$('#categoriesBtn'), dockCategories:$('#dockCategories'), surprise:$('#surpriseBtn'), dockSurprise:$('#dockSurprise'), favorites:$('#favoritesBtn'), favoriteCount:$('#favoriteCount'), lang:$('#langToggle'), categorySheet:$('#categorySheet'),
    promptSheet:$('#promptSheet'), backdrop:$('#sheetBackdrop'), categoryList:$('#categoryList'), empty:$('#emptyState'),
    resurrection:$('#resurrection'), shuffleTitle:$('#shuffleTitle'), toast:$('#toast'), install:$('#installBtn'),
    creator:$('#creatorLink'), homeCredit:$('#homeCredit'), upsell:$('#upsell'), upsellLink:$('#upsellLink'), upsellTitle:$('#upsellTitle'),
    sheetTitle:$('#sheetTitle'), sheetDescription:$('#sheetDescription'), fullPrompt:$('#fullPrompt'), tryBtn:$('#tryBtn'), viewBtn:$('#viewBtn'), favoritePromptBtn:$('#favoritePromptBtn'),
    copyBtn:$('#copyBtn'), downloadBtn:$('#downloadBtn'), shareBtn:$('#shareBtn')
  };

  function t(k){ return ui[lang][k] || k; }
  function esc(s){ return String(s).replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m])); }
  function displayCategory(value){ return lang === 'it' ? (localeData.categories?.[value] || value) : value; }
  function shortCategory(value){ return categoryShort[lang]?.[value] || displayCategory(value); }
  function displayPrompt(p){
    if(lang !== 'it') return {title:p.title, description:p.description, category:p.category};
    const loc=localeData.prompts?.[p.id] || {};
    return {title:loc.title || p.title, description:loc.description || p.description, category:displayCategory(p.category)};
  }
  function hashNum(text){ let n=0; for(const ch of text) n=(n*31+ch.charCodeAt(0))>>>0; return n; }
  function visualIndex(p,i=0){
    if(mode==='home') return [0,2,4,6][i%4];
    return (hashNum(p.id)+(i*3))%assetFamilies.length;
  }
  function thumbFor(p,i=0){ return `assets/${assetFamilies[visualIndex(p,i)]}`; }
  function categoryThumbByIndex(i){ return `assets/${assetFamilies[(i*3)%assetFamilies.length]}`; }
  function showToast(text){ els.toast.textContent=text; els.toast.classList.remove('show'); void els.toast.offsetWidth; els.toast.classList.add('show'); }

  function loadFavorites(){
    try{ const raw=JSON.parse(readStorage('dts-favorites')||'[]'); return new Set(Array.isArray(raw)?raw.filter(id=>data.some(p=>p.id===id)):[]); }
    catch{return new Set();}
  }
  function saveFavorites(){ writeStorage('dts-favorites',JSON.stringify([...favorites])); updateFavoriteUI(); }
  function isFavorite(id){ return favorites.has(id); }
  function toggleFavorite(id, quiet=false){
    if(!id) return;
    const adding=!favorites.has(id);
    if(adding) favorites.add(id); else favorites.delete(id);
    saveFavorites();
    if(!quiet) showToast(t(adding?'saved':'removed'));
    if(mode==='favorites') render(); else refreshHearts();
  }
  function updateFavoriteUI(){
    const n=favorites.size;
    els.favoriteCount.textContent=n;
    els.favoriteCount.hidden=n===0;
    if(current){
      const active=isFavorite(current.id);
      els.favoritePromptBtn.classList.toggle('active',active);
      els.favoritePromptBtn.setAttribute('aria-pressed',String(active));
      els.favoritePromptBtn.setAttribute('aria-label',t(active?'unfavorite':'favorite'));
      els.favoritePromptBtn.dataset.tooltip=t(active?'unfavorite':'favorite');
    }
  }
  function refreshHearts(){
    $$('.favorite-row').forEach(btn=>{
      const active=isFavorite(btn.dataset.id);
      btn.classList.toggle('active',active);
      btn.setAttribute('aria-pressed',String(active));
      btn.setAttribute('aria-label',t(active?'unfavorite':'favorite'));
    });
  }

  function randomDistinct(count){
    const copy=[...data];
    for(let i=copy.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[copy[i],copy[j]]=[copy[j],copy[i]];}
    return copy.slice(0,Math.min(count,copy.length));
  }

  function setDock(value){ $$('.dock-item').forEach(b=>b.classList.toggle('active',b.dataset.nav===value)); }
  function syncDock(){
    if(mode==='home') setDock('home');
    else if(mode==='favorites') setDock('favorites');
    else if(mode==='category') setDock('categories');
    else setDock(null);
  }

  function goHome(randomize=false){
    mode='home'; category=null;
    els.search.value=''; els.search.closest('.search-box').classList.remove('has-text');
    if(randomize || !homePicks.length) homePicks=randomDistinct(4);
    setDock('home');
    render();
    const main=document.querySelector('#mainPanel');
    if(main) main.scrollTo({top:0,behavior:reducedMotion?'auto':'smooth'});
    window.scrollTo({top:0,behavior:reducedMotion?'auto':'smooth'});
  }

  function applyLang(){
    document.documentElement.lang=lang;
    $$('[data-i18n]').forEach(el=>el.textContent=t(el.dataset.i18n));
    $$('[data-i18n-placeholder]').forEach(el=>el.placeholder=t(el.dataset.i18nPlaceholder));
    els.lang.textContent=lang.toUpperCase();
    els.search.setAttribute('aria-label',t('search'));
    els.home.setAttribute('aria-label',t('home')); els.brandHome.setAttribute('aria-label',t('home'));
    if(els.categories) els.categories.setAttribute('aria-label',t('categories'));
    els.dockCategories.setAttribute('aria-label',t('categories')); els.dockSurprise.setAttribute('aria-label',t('surprise')); els.favorites.setAttribute('aria-label',t('favorites'));
    els.tryBtn.textContent=t('try');
    els.viewBtn.setAttribute('aria-label',t('view')); els.viewBtn.dataset.tooltip=t('view');
    els.copyBtn.setAttribute('aria-label',t('copy')); els.copyBtn.dataset.tooltip=t('copy');
    els.downloadBtn.setAttribute('aria-label',t('download')); els.downloadBtn.dataset.tooltip=t('download');
    els.shareBtn.setAttribute('aria-label',t('share')); els.shareBtn.dataset.tooltip=t('share');
    els.clear.setAttribute('aria-label',t('clear'));
    $$('.close-sheet').forEach(b=>b.setAttribute('aria-label',t('close')));
    writeStorage('dts-lang',lang);
    render(); buildCategories(); updateFavoriteUI();
    if(current){ const d=displayPrompt(current); els.sheetTitle.textContent=d.title; els.sheetDescription.textContent=d.description || ''; }
  }

  function rowsForMode(){
    const q=els.search.value.trim().toLowerCase();
    if(mode==='home') return homePicks;
    if(mode==='favorites') return data.filter(p=>favorites.has(p.id));
    return data.filter(p=>{
      if(category && p.category!==category) return false;
      if(mode==='search' && q){
        const d=displayPrompt(p);
        return `${d.title} ${d.category} ${p.title} ${p.category}`.toLowerCase().includes(q);
      }
      return true;
    });
  }

  function rowHTML(p,i){
    const d=displayPrompt(p);
    const active=isFavorite(p.id);
    const family=visualIndex(p,i);
    return `<article class="prompt-row" tabindex="0" role="button" aria-label="${esc(d.title)}" data-id="${esc(p.id)}" style="--delay:${Math.min(i,10)*18}ms">
      <span class="row-art family-${family}" aria-hidden="true"><img src="${thumbFor(p,i)}" alt=""></span>
      <h3>${esc(d.title)}</h3>
      <button class="favorite-row${active?' active':''}" type="button" data-id="${esc(p.id)}" aria-label="${esc(t(active?'unfavorite':'favorite'))}" aria-pressed="${active}">
        <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M20.8 4.6c-2-2-5.2-2-7.2 0L12 6.2l-1.6-1.6c-2-2-5.2-2-7.2 0s-2 5.2 0 7.2L12 20.6l8.8-8.8c2-2 2-5.2 0-7.2Z"/></svg>
      </button>
      <span class="row-chevron" aria-hidden="true"></span>
    </article>`;
  }

  function render(){
    const rows=rowsForMode();
    if(els.homeCredit) els.homeCredit.hidden=mode!=='home';
    els.results.hidden=false;
    els.empty.hidden=rows.length!==0;
    const emptyStrong=els.empty.querySelector('strong');
    if(!data.length) emptyStrong.textContent=t('error');
    else if(mode==='favorites') emptyStrong.textContent=t('noFavorites');
    else emptyStrong.textContent=t('noResults');
    els.list.innerHTML=rows.map(rowHTML).join('');
    $$('.prompt-row').forEach(row=>{
      const go=()=>openPrompt(row.dataset.id);
      row.addEventListener('click',e=>{if(e.target.closest('.favorite-row'))return;go();});
      row.addEventListener('keydown',e=>{if((e.key==='Enter'||e.key===' ')&&!e.target.closest('.favorite-row')){e.preventDefault();go();}});
    });
    $$('.favorite-row').forEach(btn=>btn.addEventListener('click',e=>{e.stopPropagation();toggleFavorite(btn.dataset.id);}));
  }

  function openFavorites(){
    mode='favorites'; category=null; els.search.value=''; els.search.closest('.search-box').classList.remove('has-text'); setDock('favorites'); render();
    requestAnimationFrame(()=>els.results.scrollIntoView({behavior:reducedMotion?'auto':'smooth',block:'start'}));
  }
  function openCategory(cat){
    mode='category'; category=cat; els.search.value=''; els.search.closest('.search-box').classList.remove('has-text'); setDock('categories'); render();
    requestAnimationFrame(()=>els.results.scrollIntoView({behavior:reducedMotion?'auto':'smooth',block:'start'}));
  }

  let lockedScrollY = 0;
  function setPageScrollLock(lock){
    const body=document.body;
    if(lock){
      if(body.classList.contains('sheet-open')) return;
      lockedScrollY=window.scrollY || document.documentElement.scrollTop || 0;
      body.style.top=`-${lockedScrollY}px`;
      body.classList.add('sheet-open');
      return;
    }
    if(!body.classList.contains('sheet-open')) return;
    body.classList.remove('sheet-open');
    body.style.top='';
    window.scrollTo(0,lockedScrollY);
  }
  function showBackdrop(show){ els.backdrop.hidden=!show; setPageScrollLock(show); }
  function openSheet(sheet){
    if(!document.querySelector('.sheet.open')) lastFocus=document.activeElement;
    [els.categorySheet,els.promptSheet].forEach(other=>{
      other.classList.toggle('open',other===sheet);
      other.inert=other!==sheet;
      other.setAttribute('aria-hidden',String(other!==sheet));
    });
    showBackdrop(true);
    document.querySelector('#appShell').inert=true;
    document.querySelector('.skip-link').inert=true;
    sheet.scrollTop=0;
    sheet.querySelector('button,[tabindex]')?.focus({preventScroll:true});
  }
  function closeSheets(){
    cancelSurprise();
    const promptWasOpen=!!current;
    [els.categorySheet,els.promptSheet].forEach(s=>{s.classList.remove('open');s.inert=true;s.setAttribute('aria-hidden','true');});
    document.querySelector('#appShell').inert=false;
    document.querySelector('.skip-link').inert=false;
    showBackdrop(false);
    if(promptWasOpen){
      current=null;
      if(location.protocol.startsWith('http')&&location.hash) history.replaceState(null,'',`${location.pathname}${location.search}`);
    }
    syncDock();
    const target=lastFocus?.isConnected ? lastFocus : els.favorites;
    target?.focus({preventScroll:true});
  }
  function trapFocus(e){
    if(e.key!=='Tab') return; const open=$('.sheet.open'); if(!open)return;
    const focusables=[...open.querySelectorAll('button,[href],input,[tabindex]:not([tabindex="-1"])')].filter(x=>!x.disabled&&!x.hidden);
    if(!focusables.length)return; const first=focusables[0],last=focusables.at(-1);
    if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus();} else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus();}
  }

  function buildCategories(){
    const cats=[...new Set(data.map(p=>p.category))].sort();
    const items=[{key:'__all__',label:lang==='it'?'Tutti':'All',art:'burst.webp'},...cats.map((c,i)=>({key:c,label:shortCategory(c),art:categoryThumbByIndex(i+1).replace('assets/','')}))];
    els.categoryList.innerHTML=items.map((item,i)=>`<button class="category-app" type="button" data-cat="${esc(item.key)}">
      <span class="category-app-icon cat-${i%6}" style="--cat-art:url('assets/${esc(item.art)}')" aria-hidden="true"></span>
      <span>${esc(item.label)}</span>
    </button>`).join('');
    $$('.category-app').forEach(b=>b.addEventListener('click',()=>{const key=b.dataset.cat;closeSheets();openCategory(key==='__all__'?null:key);}));
  }

  function openCategories(){ buildCategories(); setDock('categories'); openSheet(els.categorySheet); }

  function openPrompt(id){
    current=data.find(p=>p.id===id); if(!current)return;
    const d=displayPrompt(current); els.sheetTitle.textContent=d.title; els.sheetDescription.textContent=d.description || ''; els.fullPrompt.textContent=current.prompt; els.fullPrompt.hidden=true; els.viewBtn.setAttribute('aria-expanded','false'); els.tryBtn.textContent=t('try');
    els.promptSheet.style.setProperty('--prompt-art',`url("${thumbFor(current)}")`); updateFavoriteUI(); openSheet(els.promptSheet);
    if(location.protocol.startsWith('http')) history.replaceState(null,'',`#${current.id}`);
  }

  async function copyText(text){
    try{await navigator.clipboard.writeText(text);return true;}catch{const ta=document.createElement('textarea');ta.value=text;ta.style.position='fixed';ta.style.opacity='0';document.body.appendChild(ta);ta.select();try{return document.execCommand('copy');}catch{return false;}finally{ta.remove();}}
  }
  async function copyPrompt(){if(!current)return;showToast(t(await copyText(current.prompt)?'copied':'error'));}
  function downloadPrompt(){
    if(!current)return; const d=displayPrompt(current); const text=`# ${d.title}\n\n## Prompt\n\n${current.prompt}\n`; const blob=new Blob([text],{type:'text/markdown;charset=utf-8'}); const a=document.createElement('a'); a.href=URL.createObjectURL(blob); a.download=`${current.id}-${current.title.toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'')}.md`; a.click(); setTimeout(()=>URL.revokeObjectURL(a.href),1000);
  }
  async function sharePrompt(){
    if(!current)return; const base=config.siteUrl || (location.protocol.startsWith('http')?`${location.origin}${location.pathname}`:''); const d=displayPrompt(current); const payload={title:`Dead Text Society — ${d.title}`}; if(base)payload.url=`${base.replace(/#.*$/,'')}#${current.id}`;
    try{if(navigator.share){await navigator.share(payload);}else{showToast(t(await copyText(payload.url||payload.title)?(payload.url?'shared':'copied'):'error'));}}catch(err){if(err?.name!=='AbortError'){showToast(t(await copyText(payload.url||payload.title)?(payload.url?'shared':'copied'):'error'));}}
  }

  let shuffleTimer=null, revealTimer=null;
  function cancelSurprise(){
    clearInterval(shuffleTimer); clearTimeout(revealTimer);
    shuffleTimer=null; revealTimer=null;
    els.resurrection.classList.remove('active','flash');
    els.resurrection.setAttribute('aria-hidden','true');
  }
  function surprise(){
    if(shuffleTimer!==null || revealTimer!==null)return;
    const contextual=(mode==='favorites'||mode==='category'||mode==='search') ? rowsForMode() : data;
    const pool=contextual.length ? contextual : data; if(!pool.length)return; const picked=pool[Math.floor(Math.random()*pool.length)]; setDock('surprise');
    if(reducedMotion){openPrompt(picked.id);return;}
    els.resurrection.classList.add('active'); els.resurrection.setAttribute('aria-hidden','false'); let ticks=0;
    shuffleTimer=setInterval(()=>{els.shuffleTitle.textContent=displayPrompt(pool[Math.floor(Math.random()*pool.length)]).title; ticks++; if(ticks>8){clearInterval(shuffleTimer);els.shuffleTitle.textContent=displayPrompt(picked).title;els.resurrection.classList.add('flash');revealTimer=setTimeout(()=>{cancelSurprise();openPrompt(picked.id);},520);}},85);
  }

  function applyConfig(){
    els.creator.href=config.creatorUrl||'https://linktr.ee/emaf205X';
    if(els.homeCredit) els.homeCredit.href=config.creatorUrl||'https://linktr.ee/emaf205X';
    if(config.upsell?.enabled&&config.upsell.title&&config.upsell.url){els.upsell.hidden=false;els.upsellTitle.textContent=config.upsell.title;els.upsellLink.href=config.upsell.url;}
  }
  function registerPWA(){
    if('serviceWorker'in navigator&&location.protocol.startsWith('http'))navigator.serviceWorker.register('./service-worker.js').catch(()=>{});
    window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();installEvent=e;els.install.hidden=false;});
    els.install.addEventListener('click',async()=>{if(!installEvent)return;installEvent.prompt();await installEvent.userChoice;installEvent=null;els.install.hidden=true;});
    window.addEventListener('appinstalled',()=>{els.install.hidden=true;installEvent=null;});
  }

  els.home.addEventListener('click',()=>goHome(false)); els.brandHome.addEventListener('click',()=>goHome(false));
  els.search.addEventListener('input',()=>{const has=!!els.search.value.trim();els.search.closest('.search-box').classList.toggle('has-text',has);if(has){mode='search';category=null;setDock(null);render();}else goHome(false);});
  els.clear.addEventListener('click',()=>{goHome(false);els.search.focus();});
  if(els.categories) els.categories.addEventListener('click',openCategories); els.dockCategories.addEventListener('click',openCategories);
  els.surprise.addEventListener('click',surprise); els.dockSurprise.addEventListener('click',surprise);
  els.favorites.addEventListener('click',openFavorites);
  els.lang.addEventListener('click',()=>{lang=lang==='en'?'it':'en';applyLang();});
  els.backdrop.addEventListener('click',closeSheets); $$('.close-sheet').forEach(b=>b.addEventListener('click',closeSheets));
  els.tryBtn.addEventListener('click',copyPrompt); els.copyBtn.addEventListener('click',copyPrompt);
  els.favoritePromptBtn.addEventListener('click',()=>current&&toggleFavorite(current.id));
  els.viewBtn.addEventListener('click',()=>{els.fullPrompt.hidden=!els.fullPrompt.hidden;els.viewBtn.setAttribute('aria-expanded',String(!els.fullPrompt.hidden));});
  els.downloadBtn.addEventListener('click',downloadPrompt); els.shareBtn.addEventListener('click',sharePrompt);
  document.addEventListener('keydown',e=>{if(e.key==='Escape')closeSheets();trapFocus(e);});

  applyConfig(); applyLang(); goHome(true); registerPWA();
  function openHash(){
    let hash; try{hash=decodeURIComponent(location.hash.slice(1));}catch{return;}
    if(hash&&data.some(p=>p.id===hash))openPrompt(hash);
    else if(current)closeSheets();
  }
  window.addEventListener('hashchange',openHash);
  openHash();
})();
