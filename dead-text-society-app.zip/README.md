# DEAD TEXT SOCIETY

**Give dead content another life.**

[**OPEN THE APP →**](https://emaf205.com/ideas/dead-text-society/)

---


## WHY

I teach AI and record my lessons.

**Recording → Transcript → Summary → Blog**

Useful.

But I wanted more.

**Same source → new angles → new formats → new ideas**

So I built **Dead Text Society**.

## WHAT IT DOES

**142 transformations** for existing content.

Use it on:

**transcripts · notes · PDFs · articles · research · lessons**

Turn them into:

**stories · critiques · visual concepts · future scenarios · maps · lessons · strange connections**

## HOW

**CHOOSE → COPY → ADD YOUR SOURCE → RUN**

Works with **ChatGPT · Claude · Gemini · NotebookLM · and other AI tools**.

Output follows the user's language.

---


## INSIDE

**142 prompts → Search → Categories → Surprise → Favorites**

**Offline → No account → No backend**

## WEB

[**OPEN DEAD TEXT SOCIETY →**](https://emaf205.com/ideas/dead-text-society/)

## LOCAL

`index.html`

---

**DEAD TEXT SOCIETY**  
**BY [EMANUELE BDC](https://linktr.ee/emaf205X)**

© 2026 Emanuele BDC. All rights reserved.

## Development and verification

The app has no runtime dependencies. Open `index.html` directly, or serve this folder
over HTTP on localhost / HTTPS to enable installation and offline caching.

Browser regression tests (Node.js 20+):

```sh
npm install
npx playwright install chromium
npm test
```

`DTS_CHROMIUM_PATH` can select an existing Chromium executable. Tests cover desktop
and mobile viewports, prompt data, search, categories, favorites, language,
clipboard failures, downloads, deep links, keyboard focus, scroll and offline use.
Mobile tests emulate Chromium viewports; they do not replace testing on real iOS devices.

After changing prompts: `python3 tools/sync_prompts.py`.
After changing app files: `python3 tools/build_zip.py`.
Bump the service worker cache version whenever publishing changed files.
The downloadable ZIP excludes itself; its absence does not prevent offline installation.
