# Dead Text Society — Prompt Vault

142 prompts. Master language: English.

## NAR-01 — Three-Act Conflict

**Category:** Narrative

A compact narrative with setup, fracture, and transformed understanding.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: isolate the strongest real conflict, who embodies it, what changes, and the concrete detail that makes it visible. STEP 2 — DEVIATION: reorder the source material to maximize tension and understanding. STEP 3 — CONNECTION: connect the dynamic to dramatic structure without inventing people or events. STEP 4 — TRANSFORMATION: write a three-act piece: situation, fracture, consequence, using only scenes, statements, and turns supported by the sources.

OUTPUT — 1,200–1,800 word narrative piece.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## NAR-02 — Microhistory

**Category:** Narrative

A small detail becomes the doorway to a much larger system.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: find the smallest detail with the greatest hidden implications. STEP 2 — DEVIATION: make that detail the protagonist and push the declared topic into the background. STEP 3 — CONNECTION: connect it to larger social, economic, technological, or cultural dynamics. STEP 4 — TRANSFORMATION: write a microhistory that progressively changes scale from detail to system.

OUTPUT — 900–1,400 word article.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## NAR-03 — Retrospective report from the future

**Category:** Narrative

A future-written report that rereads the sources as an early document of change.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: extract weak signals, casual remarks, and unusual behaviors that could matter later. STEP 2 — DEVIATION: observe them as if ten years had passed without assuming which signal wins. STEP 3 — CONNECTION: connect them to plausible transformations in work, culture, technology, or institutions. STEP 4 — TRANSFORMATION: write a retrospective report clearly separating source evidence from future interpretation.

OUTPUT — 1,200–1,600 word feature.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## NAR-04 — Anomaly Detective Story

**Category:** Narrative

An investigation in which the explanation is discovered progressively.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: identify the most revealing anomaly and collect all relevant clues. STEP 2 — DEVIATION: generate at least three competing explanations and reject unsupported ones. STEP 3 — CONNECTION: connect the investigation to logic, diagnosis, or scientific reasoning. STEP 4 — TRANSFORMATION: turn the analysis into a detective story: mystery, evidence, plausible false leads, provisional solution.

OUTPUT — Narrative investigation.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## NAR-05 — Oral history of a transition

**Category:** Narrative

A chorus of source voices documenting a transformation while it is happening.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: extract firsthand statements that reveal lived experience rather than abstract opinion. STEP 2 — DEVIATION: group voices by tension rather than by source order. STEP 3 — CONNECTION: connect recurring experiences to a wider historical or social transition. STEP 4 — TRANSFORMATION: compose an oral-history piece in which voices retain disagreement and specificity.

OUTPUT — 1,200–1,800 word polyphonic article.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## NAR-06 — Learning to See Differently

**Category:** Narrative

A narrative of cognitive growth rather than a summary of content.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: trace the initial assumption, confusion, trial, turning point, and later understanding. STEP 2 — DEVIATION: remove explanatory passages that do not change the protagonist's perception. STEP 3 — CONNECTION: connect the change to learning, identity, or expertise development. STEP 4 — TRANSFORMATION: write a formation story that makes the shift in perception the plot.

OUTPUT — 1,000–1,500 word narrative essay.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## NAR-07 — Failure-Driven Narrative

**Category:** Narrative

A story in which failure is the engine of understanding.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: extract mistakes, failed attempts, uncertainty, repairs, and afterthoughts. STEP 2 — DEVIATION: rank them by how much they changed the outcome or understanding. STEP 3 — CONNECTION: connect them to failure analysis and learning loops. STEP 4 — TRANSFORMATION: write a narrative where each failure produces the next level of insight.

OUTPUT — Failure-driven essay.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## NAR-08 — Hidden protagonist story

**Category:** Narrative

A narrative about the force shaping everything from the background.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: identify the actor or force that affects the entire source while remaining backgrounded. STEP 2 — DEVIATION: collect every trace of its influence. STEP 3 — CONNECTION: connect it to power, infrastructure, incentives, or institutional design. STEP 4 — TRANSFORMATION: rewrite the story with this hidden force as the protagonist while keeping all facts source-grounded.

OUTPUT — Narrative reframing.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## CRI-01 — Intellectual autopsy of the central idea

**Category:** Critique

A dissection of assumptions, mechanisms, dependencies, weak points, and consequences.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: isolate the core claim and list what must be true for it to work. STEP 2 — DEVIATION: separate mechanism from rhetoric and evidence from interpretation. STEP 3 — CONNECTION: connect its structure to at least two distant disciplines. STEP 4 — TRANSFORMATION: write an intellectual autopsy showing organs, dependencies, failure points, and unresolved questions.

OUTPUT — Critical essay.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## CRI-02 — Trial of the main thesis

**Category:** Critique

A structured prosecution and defense built from the sources.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: state the strongest defensible version of the thesis. STEP 2 — DEVIATION: collect evidence for and against it and identify missing evidence. STEP 3 — CONNECTION: connect the dispute to legal standards of proof and scientific falsifiability. STEP 4 — TRANSFORMATION: build prosecution, defense, witnesses, exhibits, cross-examination, and a reasoned verdict.

OUTPUT — Argumentative trial.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## CRI-03 — Map of contradictions

**Category:** Critique

A structured inventory of tensions that should not be prematurely resolved.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: extract contradictions, double binds, and incompatible goals. STEP 2 — DEVIATION: distinguish genuine contradiction from mere difference. STEP 3 — CONNECTION: connect each tension to a broader conceptual conflict. STEP 4 — TRANSFORMATION: produce a contradiction atlas explaining why each tension matters and what it makes visible.

OUTPUT — Contradiction atlas.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## CRI-04 — The missing evidence audit

**Category:** Critique

An analysis of what would have to be known before stronger conclusions are justified.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: list the strongest conclusions. STEP 2 — DEVIATION: for each, identify evidence present, evidence absent, and evidence that could reverse the conclusion. STEP 3 — CONNECTION: connect the gaps to research design and burden of proof. STEP 4 — TRANSFORMATION: produce an evidence-gap report with priority questions for verification.

OUTPUT — Evidence audit.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## CRI-05 — Assumption excavation

**Category:** Critique

A reconstruction of what the sources silently take for granted.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: extract repeated claims and ask what must be assumed for them to make sense. STEP 2 — DEVIATION: separate explicit premises from hidden ones. STEP 3 — CONNECTION: connect hidden assumptions to culture, institutions, incentives, and historical context. STEP 4 — TRANSFORMATION: write an assumption map showing which conclusions collapse if each premise changes.

OUTPUT — Assumption map.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## CRI-06 — Strongest alternative interpretation

**Category:** Critique

A rival reading designed to explain the same evidence better.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: state the dominant interpretation as precisely as possible. STEP 2 — RIVAL: build one genuinely different interpretation that explains the same evidence with as few extra assumptions as possible. STEP 3 — COLLISION: show which observations each interpretation explains better, worse, or not at all. STEP 4 — DISCRIMINATOR: identify the specific evidence that would decide between the two readings.

OUTPUT — Comparative critical essay.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## CRI-07 — Boundary conditions analysis

**Category:** Critique

A precise account of when an idea works, stops working, or reverses.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: identify the claim's implied domain. STEP 2 — DEVIATION: search for limits, exceptions, thresholds, and contextual dependencies. STEP 3 — CONNECTION: connect these boundaries to causal and engineering thinking. STEP 4 — TRANSFORMATION: rewrite the claim with explicit conditions, limits, and failure modes.

OUTPUT — Boundary-condition brief.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## CRI-08 — Critique from the margins

**Category:** Critique

A reading focused on actors, costs, or perspectives absent from the center.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: identify who speaks, who acts, who benefits, who pays, and who is absent. STEP 2 — DEVIATION: avoid inventing motives or experiences not in evidence. STEP 3 — CONNECTION: connect absences to stakeholder and power analysis. STEP 4 — TRANSFORMATION: write a critique organized around what becomes visible when the center is displaced.

OUTPUT — Critical essay.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## INT-01 — Five-Discipline Inspection

**Category:** Interdisciplinary

Five different fields reveal five different realities in the same sources.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: reduce the material to its deepest mechanism. STEP 2 — DEVIATION: choose five genuinely different but relevant disciplines. STEP 3 — CONNECTION: for each, identify what it notices that the others miss. STEP 4 — TRANSFORMATION: synthesize the one insight that becomes possible only through comparison.

OUTPUT — Five-lens analysis.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## INT-02 — Fusion of two distant disciplines

**Category:** Interdisciplinary

A new model created by combining two fields that normally do not meet.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: define the source problem structurally rather than by topic label. STEP 2 — DEVIATION: select two distant disciplines with compatible structures. STEP 3 — CONNECTION: map at least three nontrivial correspondences between them. STEP 4 — TRANSFORMATION: build and test a hybrid model against the sources, rejecting decorative analogies.

OUTPUT — Original hybrid framework.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## INT-03 — Biological Reading

**Category:** Interdisciplinary

A reinterpretation through metabolism, immunity, adaptation, ecology, or evolution.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: identify flows, boundaries, adaptation, replication, and failure in the sources. STEP 2 — DEVIATION: choose the biological mechanism that matches structurally. STEP 3 — CONNECTION: test where the analogy holds and breaks. STEP 4 — TRANSFORMATION: use it to produce a new explanation rather than a metaphorical rewrite.

OUTPUT — Biological systems essay.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## INT-04 — Architecture of the Invisible

**Category:** Interdisciplinary

A model of foundations, load-bearing elements, circulation, interfaces, and failure.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: identify foundations, load-bearing dependencies, interfaces, flows, and bottlenecks. STEP 2 — DEVIATION: translate them into architectural functions rather than decorative imagery. STEP 3 — CONNECTION: connect spatial logic to the source system. STEP 4 — TRANSFORMATION: produce a blueprint-style interpretation with structural weaknesses and redesign opportunities.

OUTPUT — Conceptual blueprint.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## INT-05 — Musical reading of coordination

**Category:** Interdisciplinary

A reading of rhythm, synchronization, improvisation, hierarchy, and silence.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: extract recurring rhythms, handoffs, timing problems, solo roles, and moments of silence. STEP 2 — DEVIATION: compare them to ensemble coordination. STEP 3 — CONNECTION: identify where synchronization or improvisation creates value or failure. STEP 4 — TRANSFORMATION: build an interpretation that explains coordination through musical structure.

OUTPUT — Coordination essay.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## INT-06 — Legal reading of a non-legal system

**Category:** Interdisciplinary

An analysis of permission, authority, responsibility, evidence, and accountability.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: extract who may act, who authorizes, who verifies, and who is accountable. STEP 2 — DEVIATION: identify ambiguous responsibility and missing procedural safeguards. STEP 3 — CONNECTION: connect these to due process, delegation, and liability. STEP 4 — TRANSFORMATION: reframe the system as a constitutional or procedural architecture.

OUTPUT — Governance analysis.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## INT-07 — Theatre of Organization

**Category:** Interdisciplinary

An analysis of roles, scripts, backstage activity, performance, and audience.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: separate declared roles from performed roles. STEP 2 — DEVIATION: identify scripts, improvisations, backstage repairs, and audiences. STEP 3 — CONNECTION: connect them to dramaturgical sociology. STEP 4 — TRANSFORMATION: write a critique of the system as performance rather than structure alone.

OUTPUT — Dramaturgical essay.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## INT-08 — Physics of the phenomenon

**Category:** Interdisciplinary

A structural reading through forces, friction, inertia, thresholds, and phase changes.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: identify forces, resistances, accumulations, thresholds, and abrupt shifts. STEP 2 — DEVIATION: select physical concepts only when they map structurally. STEP 3 — CONNECTION: test each mapping against source evidence. STEP 4 — TRANSFORMATION: derive a new explanation of stability, transition, or collapse.

OUTPUT — Systems essay.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## SYS-01 — Hidden economy of the sources

**Category:** Systems / Economics

A balance sheet of time, money, attention, coordination, risk, and opportunity.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: extract all explicit and implicit costs and benefits. STEP 2 — DEVIATION: include hidden costs such as waiting, rework, attention, uncertainty, and coordination. STEP 3 — CONNECTION: connect them to transaction-cost and behavioral economics. STEP 4 — TRANSFORMATION: build an economic map that shows who pays, who saves, and where value moves.

OUTPUT — Economic analysis.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## SYS-02 — Feedback-loop map

**Category:** Systems / Economics

A causal map of reinforcing and balancing loops.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — VARIABLES: extract the smallest set of variables that actually change over time. STEP 2 — LOOPS: connect them into reinforcing and balancing feedback loops supported by the sources. STEP 3 — DELAYS: mark delays, thresholds, and places where actors adapt. STEP 4 — LEVERAGE: explain which loop appears dominant, where intervention could change behavior, and what unintended feedback might follow.

OUTPUT — Causal-loop analysis.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## SYS-03 — Bottleneck surgery

**Category:** Systems / Economics

A diagnosis of the constraint that limits the whole system.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: map the end-to-end process. STEP 2 — DEVIATION: identify where work, information, or decisions accumulate. STEP 3 — CONNECTION: test whether the visible problem is the true constraint or a symptom. STEP 4 — TRANSFORMATION: propose source-grounded leverage points and explain likely side effects.

OUTPUT — Constraint analysis.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## SYS-04 — Second- and third-order consequences

**Category:** Systems / Economics

A futures-oriented expansion of indirect effects.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: select one high-leverage change from the sources. STEP 2 — DEVIATION: map immediate effects. STEP 3 — CONNECTION: identify how actors adapt to those effects. STEP 4 — TRANSFORMATION: derive second- and third-order consequences, including rebound effects.

OUTPUT — Consequence chain.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## SYS-05 — Incentive map

**Category:** Systems / Economics

An explanation of behavior through rewards, penalties, status, convenience, and risk.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: list the key actors. STEP 2 — DEVIATION: for each, identify explicit and implicit incentives. STEP 3 — CONNECTION: compare incentives with declared goals. STEP 4 — TRANSFORMATION: show where system behavior becomes rational for individuals but harmful for the whole.

OUTPUT — Incentive analysis.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## SYS-06 — Coordination-cost anatomy

**Category:** Systems / Economics

A map of the invisible work required to make multiple actors cooperate.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: extract every handoff, approval, clarification, verification, and synchronization step. STEP 2 — DEVIATION: estimate qualitatively which create the most coordination burden. STEP 3 — CONNECTION: connect them to transaction and information costs. STEP 4 — TRANSFORMATION: show which complexity is productive and which is pure overhead.

OUTPUT — Coordination-cost essay.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## SYS-07 — Leverage-point analysis

**Category:** Systems / Economics

A ranked search for changes that alter the system disproportionately.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: map structure, rules, information flows, incentives, and goals. STEP 2 — DEVIATION: generate possible intervention points at several depths. STEP 3 — CONNECTION: distinguish parameter tweaks from structural changes. STEP 4 — TRANSFORMATION: select the strongest leverage points and explain risks of unintended effects.

OUTPUT — Leverage-point brief.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## SYS-08 — System failure cascade

**Category:** Systems / Economics

A reconstruction of how a small fault can propagate.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: identify possible initiating failures supported by the sources. STEP 2 — DEVIATION: trace dependencies and handoffs. STEP 3 — CONNECTION: model how one failure could cascade through the system. STEP 4 — TRANSFORMATION: identify detection points, containment gates, and recovery mechanisms.

OUTPUT — Failure-cascade analysis.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## FUT-01 — Weak-signal radar

**Category:** Future / Signals

A disciplined scan for small anomalies that may foreshadow larger change.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: extract unusual behaviors, workarounds, vocabulary, and edge cases. STEP 2 — DEVIATION: separate novelty from signals with a plausible mechanism. STEP 3 — CONNECTION: connect each signal to a deeper driver. STEP 4 — TRANSFORMATION: rank signals by potential impact and observability.

OUTPUT — Signal radar.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## FUT-02 — Scenario 2035

**Category:** Future / Signals

A plausible future built from current traces rather than free invention.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: identify stable drivers, uncertain variables, and weak signals. STEP 2 — DEVIATION: build two or three critical uncertainties. STEP 3 — CONNECTION: construct a coherent 2035 scenario from their interaction. STEP 4 — TRANSFORMATION: mark every element as evidence, inference, or speculation.

OUTPUT — Future scenario.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## FUT-03 — What becomes normal?

**Category:** Future / Signals

An analysis of today's unusual behavior as tomorrow's routine.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: identify practices currently treated as exceptional. STEP 2 — DEVIATION: ask what infrastructure, norms, or incentives would make them ordinary. STEP 3 — CONNECTION: connect them to prior normalization processes. STEP 4 — TRANSFORMATION: write a future-normality analysis including what would disappear from attention once normalized.

OUTPUT — Normalization essay.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## FUT-04 — Future museum exhibit

**Category:** Future / Signals

A curated set of present-day artifacts explained from a later era.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: select seven artifacts from the sources. STEP 2 — DEVIATION: write what each reveals about today's assumptions. STEP 3 — CONNECTION: connect them into a single curatorial thesis. STEP 4 — TRANSFORMATION: create future-facing exhibit labels without pretending speculative claims are facts.

OUTPUT — Museum mini-exhibit.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## FUT-05 — Obituary for a method

**Category:** Future / Signals

A rigorous argument that a current practice may be losing its reason to exist.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: identify a method the sources portray as increasingly inefficient or redundant. STEP 2 — DEVIATION: document what problem it originally solved. STEP 3 — CONNECTION: show what has changed. STEP 4 — TRANSFORMATION: write its obituary while naming the conditions under which it may survive.

OUTPUT — Argumentative obituary.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## FUT-06 — Birth certificate for a new profession

**Category:** Future / Signals

A profile of an emerging role created by combining tasks and responsibilities.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: extract recurring tasks, decisions, and accountabilities. STEP 2 — DEVIATION: identify which currently belong to different roles. STEP 3 — CONNECTION: find the new coordination problem created by their convergence. STEP 4 — TRANSFORMATION: define the emerging profession, its value, limits, and skills.

OUTPUT — Future job profile.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## FUT-07 — Pre-mortem from five years ahead

**Category:** Future / Signals

A future failure analysis written as if the initiative has already failed.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: identify the source-backed initiative, promise, or direction and the assumptions holding it together. STEP 2 — TIME JUMP: move five years forward and assume it failed after initially looking plausible. STEP 3 — RETROSPECTIVE: reconstruct the sequence—early weak signals, ignored trade-offs, actor adaptations, lock-in, and compounding decisions—distinguishing present evidence from projected scenario. STEP 4 — TRANSFORMATION: write a five-years-later postmortem that ends with the signals people today would wish they had noticed.

OUTPUT — Pre-mortem report.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## FUT-08 — Counterfactual future branch

**Category:** Future / Signals

A comparison of two futures created by one decision changing.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: identify one pivotal decision. STEP 2 — DEVIATION: construct a baseline path and an alternative path. STEP 3 — CONNECTION: trace how actors adapt differently. STEP 4 — TRANSFORMATION: compare second-order effects without claiming prediction.

OUTPUT — Two-branch scenario.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## PSY-01 — Cognitive transformation map

**Category:** Psychology / Society

A reconstruction of how a person's mental model changes.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: identify initial beliefs, surprises, disconfirming evidence, and revised beliefs. STEP 2 — DEVIATION: find the exact trigger of each shift. STEP 3 — CONNECTION: connect the sequence to learning and cognitive dissonance. STEP 4 — TRANSFORMATION: build a before/during/after map of the mental model.

OUTPUT — Cognitive-change analysis.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## PSY-02 — Bias audit

**Category:** Psychology / Society

A source-grounded scan for recurring cognitive shortcuts.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: identify decisions and judgments. STEP 2 — DEVIATION: test for plausible biases without diagnosing people. STEP 3 — CONNECTION: separate evidence of bias from mere possibility. STEP 4 — TRANSFORMATION: show how alternative procedures could reduce the observed vulnerability.

OUTPUT — Bias audit.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## PSY-03 — Social norm detector

**Category:** Psychology / Society

An analysis of what people do because it feels normal, expected, or legitimate.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: extract repeated behaviors and language that signal norms. STEP 2 — DEVIATION: identify sanctions, rewards, embarrassment, or legitimacy cues. STEP 3 — CONNECTION: connect them to norm formation and conformity. STEP 4 — TRANSFORMATION: show how norms stabilize behavior and what could shift them.

OUTPUT — Norm analysis.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## PSY-04 — Identity under pressure

**Category:** Psychology / Society

A study of how new practices challenge professional or personal identity.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: identify statements about who people are, what counts as expertise, and what feels legitimate. STEP 2 — DEVIATION: track moments where tools or systems threaten those identities. STEP 3 — CONNECTION: connect the tension to professional identity and status. STEP 4 — TRANSFORMATION: write an analysis of identity negotiation grounded in the sources.

OUTPUT — Identity essay.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## PSY-05 — Trust architecture

**Category:** Psychology / Society

A map of how trust is produced, transferred, checked, and broken.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: identify where trust is assumed, earned, verified, or repaired. STEP 2 — DEVIATION: separate trust in people, processes, outputs, and institutions. STEP 3 — CONNECTION: connect the source pattern to trust mechanisms. STEP 4 — TRANSFORMATION: design a trust architecture showing where verification matters most.

OUTPUT — Trust analysis.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## PSY-06 — Power hidden in workflow

**Category:** Psychology / Society

A sociological reading of who controls information, timing, permission, and validation.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: map who can initiate, block, approve, interpret, and redefine work. STEP 2 — DEVIATION: identify informal power not captured by titles. STEP 3 — CONNECTION: connect power to information and dependency. STEP 4 — TRANSFORMATION: write a source-grounded power analysis without imputing motives.

OUTPUT — Power analysis.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## PSY-07 — Collective sensemaking

**Category:** Psychology / Society

A study of how groups build a shared interpretation under uncertainty.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: extract questions, reframings, corrections, and repeated explanations. STEP 2 — DEVIATION: identify moments where the group's shared model changes. STEP 3 — CONNECTION: connect them to collective cognition. STEP 4 — TRANSFORMATION: reconstruct the group's sensemaking process step by step.

OUTPUT — Sensemaking narrative.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## PSY-08 — Emotional infrastructure

**Category:** Psychology / Society

An analysis of frustration, enthusiasm, fear, relief, and curiosity as functional forces.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: identify emotional signals actually present. STEP 2 — DEVIATION: link them to decisions, persistence, avoidance, or attention. STEP 3 — CONNECTION: avoid inventing inner states not evidenced. STEP 4 — TRANSFORMATION: explain how emotion becomes part of the system's functioning.

OUTPUT — Affective analysis.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## HIS-01 — Genealogy of the central idea

**Category:** History / Philosophy

A lineage linking a current idea to older intellectual or institutional ancestors.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: identify the central modern concept. STEP 2 — DEVIATION: search conceptually for older structures that solved similar problems. STEP 3 — CONNECTION: connect them across philosophy, industry, science, politics, or religion. STEP 4 — TRANSFORMATION: write a genealogy that highlights continuity, mutation, and genuine novelty.

OUTPUT — Historical essay.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## HIS-02 — Philosophical thought experiment

**Category:** History / Philosophy

A source-grounded thesis pushed to an extreme to expose its hidden commitments.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: extract a defensible thesis. STEP 2 — DEVIATION: push it to a logically coherent extreme. STEP 3 — CONNECTION: identify paradoxes involving responsibility, agency, freedom, identity, or knowledge. STEP 4 — TRANSFORMATION: use the thought experiment to reveal assumptions rather than to predict reality.

OUTPUT — Thought experiment.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## HIS-03 — Socratic reconstruction

**Category:** History / Philosophy

A dialogue that advances through real questions instead of exposition.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: extract the deepest questions and objections. STEP 2 — DEVIATION: reorder them from basic to destabilizing. STEP 3 — CONNECTION: connect each answer to a new question rather than a conclusion. STEP 4 — TRANSFORMATION: write a Socratic dialogue faithful to source positions while removing repetition.

OUTPUT — Dialogue.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## HIS-04 — Historical parallel with a difference

**Category:** History / Philosophy

A comparison to a past transition that highlights both analogy and non-analogy.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: identify the present mechanism. STEP 2 — DEVIATION: choose a historical transition with at least three structural similarities. STEP 3 — CONNECTION: identify at least three decisive differences. STEP 4 — TRANSFORMATION: use the comparison to sharpen the present rather than claim history repeats.

OUTPUT — Comparative essay.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## HIS-05 — Ethics of delegation

**Category:** History / Philosophy

A philosophical analysis of responsibility when action is delegated.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: identify who decides, acts, verifies, and bears consequences. STEP 2 — DEVIATION: locate gaps between control and responsibility. STEP 3 — CONNECTION: connect them to moral agency and delegation. STEP 4 — TRANSFORMATION: write an ethics analysis distinguishing legal, operational, and moral responsibility.

OUTPUT — Ethics essay.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## HIS-06 — What counts as knowledge here?

**Category:** History / Philosophy

An epistemological analysis of evidence, expertise, testimony, and verification.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: classify claims by source of knowledge. STEP 2 — DEVIATION: identify where testimony, expertise, data, or inference are trusted. STEP 3 — CONNECTION: test standards of verification. STEP 4 — TRANSFORMATION: show what the sources treat as knowledge and where those standards conflict.

OUTPUT — Epistemology essay.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## HIS-07 — Progress or substitution?

**Category:** History / Philosophy

A historical-philosophical distinction between true capability gain and mere replacement.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: identify what the new approach changes. STEP 2 — DEVIATION: separate tasks removed, tasks shifted, and capabilities genuinely created. STEP 3 — CONNECTION: compare with earlier technological substitutions. STEP 4 — TRANSFORMATION: write an analysis of what is actually new rather than merely relocated.

OUTPUT — Critical essay.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## HIS-08 — Chronicle of a concept changing meaning

**Category:** History / Philosophy

A semantic history built from how one key term shifts across sources.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: choose one recurring high-stakes term. STEP 2 — DEVIATION: collect its uses and implied meanings. STEP 3 — CONNECTION: identify contradictions and semantic drift. STEP 4 — TRANSFORMATION: reconstruct how the term changes and why that matters for the argument.

OUTPUT — Concept history.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## EDI-01 — Evidence-Backed Manifesto

**Category:** Editorial / Formats

A set of memorable principles that remain anchored in evidence.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: extract the strongest non-obvious claims. STEP 2 — DEVIATION: rewrite each as a sharp principle. STEP 3 — CONNECTION: test each against source evidence and remove slogans that exceed it. STEP 4 — TRANSFORMATION: organize the principles into a cumulative argument rather than a list of opinions.

OUTPUT — 10–15 point manifesto.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## EDI-02 — Anti-manifesto: what should stop

**Category:** Editorial / Formats

A forceful inventory of practices, beliefs, or habits the sources implicitly reject.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: identify behaviors or assumptions that repeatedly fail. STEP 2 — DEVIATION: separate what should stop from what merely needs improvement. STEP 3 — CONNECTION: connect each to its hidden cost. STEP 4 — TRANSFORMATION: write an anti-manifesto with evidence, consequence, and replacement principle.

OUTPUT — Anti-manifesto.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## EDI-03 — Field guide

**Category:** Editorial / Formats

A practical guide for recognizing phenomena in the wild.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: extract recurring patterns, symptoms, and contexts. STEP 2 — DEVIATION: group them into recognizable types. STEP 3 — CONNECTION: for each type define signs, risks, and what to do next. STEP 4 — TRANSFORMATION: write a field guide optimized for rapid recognition.

OUTPUT — Field guide.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## EDI-04 — Case-study dossier

**Category:** Editorial / Formats

A rigorous case organized around problem, intervention, outcome, and lessons.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: select the richest concrete case. STEP 2 — DEVIATION: reconstruct context, problem, constraints, decisions, outcome, and uncertainty. STEP 3 — CONNECTION: connect it to a broader principle. STEP 4 — TRANSFORMATION: write a case study that distinguishes observed results from interpretation.

OUTPUT — Case study.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## EDI-05 — FAQ that becomes progressively deeper

**Category:** Editorial / Formats

A sequence from practical questions to conceptual consequences.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: collect recurring questions. STEP 2 — DEVIATION: rank them from operational to conceptual. STEP 3 — CONNECTION: rewrite answers to reveal the next deeper question. STEP 4 — TRANSFORMATION: build a FAQ whose final questions reach the hidden thesis.

OUTPUT — Layered FAQ.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## EDI-06 — Missing Vocabulary

**Category:** Editorial / Formats

A vocabulary for recurring phenomena lacking precise labels.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: find repeated phenomena described indirectly. STEP 2 — DEVIATION: define boundaries and distinguishing features. STEP 3 — CONNECTION: coin or select precise terms. STEP 4 — TRANSFORMATION: build a glossary with definition, example, non-example, and why the term matters.

OUTPUT — Concept glossary.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## EDI-07 — Executive memo from messy material

**Category:** Editorial / Formats

A concise decision document that preserves uncertainty.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: extract decision-relevant facts. STEP 2 — DEVIATION: separate signal from context and unresolved uncertainty. STEP 3 — CONNECTION: connect evidence to choices and trade-offs. STEP 4 — TRANSFORMATION: write a memo with issue, evidence, options, risks, and next action.

OUTPUT — Executive memo.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## EDI-08 — Editorial series map

**Category:** Editorial / Formats

A single source becomes a coherent sequence of distinct articles.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: extract all ideas capable of living independently. STEP 2 — DEVIATION: cluster them by reader need rather than source order. STEP 3 — CONNECTION: eliminate overlapping angles. STEP 4 — TRANSFORMATION: design an editorial series with title, premise, evidence base, and why each piece deserves to exist.

OUTPUT — Series plan.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## VIS-01 — Single symbolic editorial image

**Category:** Visual / Images

One powerful image that compresses the central tension without literal illustration.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: identify the central tension, not the topic label. STEP 2 — DEVIATION: find one concrete object or spatial relation that embodies it. STEP 3 — CONNECTION: avoid generic AI, lightbulb, brain, robot, and handshake clichés. STEP 4 — TRANSFORMATION: write a precise image-generation brief describing subject, composition, symbolism, mood, and what must not appear.

OUTPUT — Image prompt.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## VIS-02 — Distant-Discipline Metaphor

**Category:** Visual / Images

An image that explains the source through biology, architecture, music, law, or physics.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: reduce the phenomenon to its mechanism. STEP 2 — DEVIATION: search distant disciplines for a matching structure. STEP 3 — CONNECTION: test the analogy for at least three valid correspondences. STEP 4 — TRANSFORMATION: turn the best analogy into a visual concept and a production-ready prompt.

OUTPUT — Image concept + prompt.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## VIS-03 — Before/after without clichés

**Category:** Visual / Images

A visual contrast showing a genuine change in structure, not cosmetic improvement.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: define exactly what changes before and after. STEP 2 — DEVIATION: identify one spatial composition that makes the structural change visible. STEP 3 — CONNECTION: avoid split-screen clichés unless structurally necessary. STEP 4 — TRANSFORMATION: write a prompt where the difference is legible without explanatory text.

OUTPUT — Image prompt.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## VIS-04 — Invisible system made visible

**Category:** Visual / Images

A visual representation of flows, dependencies, permissions, or hidden forces.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: map the invisible components and relationships. STEP 2 — DEVIATION: choose whether the image should resemble anatomy, infrastructure, ecology, or circuitry. STEP 3 — CONNECTION: prioritize causal clarity over decoration. STEP 4 — TRANSFORMATION: write a visual brief that makes the hidden system intuitively visible.

OUTPUT — Visual brief.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## VIS-05 — Human-scale consequence image

**Category:** Visual / Images

A visual that shows what an abstract change means for one person in one concrete moment.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: identify the most human consequence in the sources. STEP 2 — DEVIATION: find a plausible source-grounded moment that embodies it. STEP 3 — CONNECTION: avoid inventing biographical details. STEP 4 — TRANSFORMATION: write a documentary-style image brief focused on gesture, environment, and consequence.

OUTPUT — Image brief.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## VIS-06 — Contradiction image

**Category:** Visual / Images

A single composition that contains two truths in tension.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: identify a real contradiction. STEP 2 — DEVIATION: find two visual elements whose relationship embodies it. STEP 3 — CONNECTION: avoid arbitrary surrealism. STEP 4 — TRANSFORMATION: write a controlled surreal image prompt in which the contradiction is immediately legible.

OUTPUT — Image prompt.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## VIS-07 — Archive artifact image

**Category:** Visual / Images

A fictionalized presentation of a real source element as an artifact from another time.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: select one real artifact, quote, interface, object, or practice. STEP 2 — DEVIATION: preserve its factual core. STEP 3 — CONNECTION: recontextualize it as an archival exhibit without altering what it originally was. STEP 4 — TRANSFORMATION: write a prompt for museum-grade documentation or archival photography.

OUTPUT — Image prompt.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## VIS-08 — Visual sequence of a mental-model shift

**Category:** Visual / Images

A short sequence showing how understanding changes stage by stage.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: extract the stages of conceptual change. STEP 2 — DEVIATION: assign each stage one visual state. STEP 3 — CONNECTION: keep the same protagonist/object so change is comparable. STEP 4 — TRANSFORMATION: write prompts for 4–6 coherent frames with consistent composition.

OUTPUT — Prompt sequence.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## MAP-01 — Causal-loop infographic

**Category:** Infographics / Maps

A diagram of reinforcing and balancing dynamics.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — EXTRACT: identify the variables and causal relationships that deserve to appear visually. STEP 2 — CLASSIFY: mark each connection as reinforcing, balancing, delayed, uncertain, or conditional. STEP 3 — DESIGN: specify the diagram layout, node hierarchy, arrow directions, labels, legend, and visual emphasis so a designer can build it without rereading the sources. STEP 4 — CAPTION: provide a concise explanation of how to read the map and the single loop that matters most.

OUTPUT — Diagram spec.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## MAP-02 — Stakeholder-power map

**Category:** Infographics / Maps

A map of actors by influence, dependency, exposure, and accountability.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: extract all actors and roles. STEP 2 — DEVIATION: score qualitatively influence, dependency, exposure, and accountability. STEP 3 — CONNECTION: identify missing or voiceless stakeholders. STEP 4 — TRANSFORMATION: create a map specification that reveals asymmetry rather than simply listing actors.

OUTPUT — Map spec.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## MAP-03 — Timeline of turning points

**Category:** Infographics / Maps

A chronological map of decisions, surprises, failures, and reframings.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: extract events that changed direction. STEP 2 — DEVIATION: remove routine events. STEP 3 — CONNECTION: annotate each turning point with trigger and consequence. STEP 4 — TRANSFORMATION: create a timeline specification emphasizing causal transitions.

OUTPUT — Timeline spec.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## MAP-04 — Concept map of hidden relationships

**Category:** Infographics / Maps

A network that reorganizes source material by relationship rather than document structure.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: extract key concepts. STEP 2 — DEVIATION: group by causal, analogical, hierarchical, and tension relationships. STEP 3 — CONNECTION: remove weak edges. STEP 4 — TRANSFORMATION: produce a concept-map specification and explain the three most surprising connections.

OUTPUT — Map spec.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## MAP-05 — Iceberg of visible and invisible factors

**Category:** Infographics / Maps

A layered infographic separating events, patterns, structures, and mental models.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: classify source evidence into event, pattern, structure, and underlying assumption. STEP 2 — DEVIATION: test whether each deeper layer actually explains the layer above. STEP 3 — CONNECTION: connect the layers so each deeper level explains the one above rather than merely sitting beneath it. STEP 4 — TRANSFORMATION: turn the hierarchy into a concise iceberg infographic with evidence notes and a one-sentence reading guide.

OUTPUT — Infographic copy.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## MAP-06 — Decision tree from source evidence

**Category:** Infographics / Maps

A practical tree connecting conditions to choices and checks.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: extract recurring decision points. STEP 2 — DEVIATION: identify relevant conditions and failure risks. STEP 3 — CONNECTION: build branches that use source-grounded criteria. STEP 4 — TRANSFORMATION: produce a decision-tree specification with checkpoints and stop conditions.

OUTPUT — Decision tree.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## MAP-07 — Evidence ladder

**Category:** Infographics / Maps

A visual hierarchy from observation to inference to hypothesis.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: classify statements by evidential status. STEP 2 — DEVIATION: separate direct observation, reported experience, interpretation, inference, and speculation. STEP 3 — CONNECTION: flag jumps across levels. STEP 4 — TRANSFORMATION: create a ladder showing where confidence changes.

OUTPUT — Evidence map.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## MAP-08 — Systems architecture map

**Category:** Infographics / Maps

A layered visual of actors, tools, data, decisions, and controls.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: extract components, interfaces, data flows, decision nodes, and quality gates. STEP 2 — DEVIATION: group them into layers. STEP 3 — CONNECTION: identify single points of failure. STEP 4 — TRANSFORMATION: produce a diagram brief suitable for a clean architecture infographic.

OUTPUT — Architecture spec.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## VID-01 — Three-minute documentary short

**Category:** Video / Audio

A compressed documentary arc using only source-grounded material.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: select one central question. STEP 2 — DEVIATION: choose three source moments that progressively answer it. STEP 3 — CONNECTION: identify voiceover, direct quotes, and visual evidence. STEP 4 — TRANSFORMATION: write a 3-minute treatment with opening image, escalation, reveal, and closing image.

OUTPUT — Video treatment.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## VID-02 — Video essay with one surprising thesis

**Category:** Video / Audio

An argument built through voiceover, evidence, and visual counterpoint.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: find the least obvious defensible thesis. STEP 2 — DEVIATION: collect evidence and counter-evidence. STEP 3 — CONNECTION: design visual material that adds meaning rather than illustrating words literally. STEP 4 — TRANSFORMATION: write a scene-by-scene video essay outline with narration purpose and visual purpose separated.

OUTPUT — Video essay script outline.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## VID-03 — Podcast episode as an investigation

**Category:** Video / Audio

An audio narrative that moves through questions, evidence, and competing interpretations.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: define one unresolved question. STEP 2 — DEVIATION: select source voices and evidence around it. STEP 3 — CONNECTION: organize them as competing interpretations. STEP 4 — TRANSFORMATION: write a podcast structure with cold open, investigation, turning point, and unresolved edge.

OUTPUT — Podcast outline.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## VID-04 — Audio collage of source voices

**Category:** Video / Audio

A polyphonic piece where juxtaposition creates meaning.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: extract short source-grounded voice moments. STEP 2 — DEVIATION: group them by tension rather than chronology. STEP 3 — CONNECTION: design repetition, contrast, silence, and escalation. STEP 4 — TRANSFORMATION: write an edit script that lets juxtaposition produce the argument.

OUTPUT — Audio edit script.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## VID-05 — Explainer Without Explaining

**Category:** Video / Audio

A visual narrative where a system is understood through one concrete example unfolding.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: choose one representative case. STEP 2 — DEVIATION: follow it through the whole system. STEP 3 — CONNECTION: reveal concepts only when the case encounters them. STEP 4 — TRANSFORMATION: write a 4–6 minute explainer treatment where explanation emerges from action.

OUTPUT — Explainer treatment.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## VID-06 — Debate episode

**Category:** Video / Audio

A structured collision between two source-grounded interpretations.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: formulate two strongest opposing positions. STEP 2 — DEVIATION: give each the best supporting evidence. STEP 3 — CONNECTION: identify the point where they talk past each other. STEP 4 — TRANSFORMATION: write a moderated debate outline that forces agreement on facts before disagreement on interpretation.

OUTPUT — Debate script.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## VID-07 — One-scene cinematic adaptation

**Category:** Video / Audio

A single scene that embodies the full conceptual problem.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: find the most representative moment. STEP 2 — DEVIATION: identify stakes, action, subtext, and turning point. STEP 3 — CONNECTION: remove explanatory dialogue. STEP 4 — TRANSFORMATION: write one cinematic scene faithful to the event's conceptual truth.

OUTPUT — Screenplay scene.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## VID-08 — Trailer for an idea

**Category:** Video / Audio

A 60–90 second sequence designed to create intellectual curiosity rather than summarize.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: extract the most destabilizing questions and moments. STEP 2 — DEVIATION: arrange them for escalation. STEP 3 — CONNECTION: withhold the conclusion. STEP 4 — TRANSFORMATION: write a trailer script with image beats, audio beats, and final unresolved question.

OUTPUT — Trailer script.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## TEA-01 — Socratic Tension Lesson

**Category:** Teaching / Interactive

A lesson driven by questions that force learners to reconstruct the insight.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: identify the final insight. STEP 2 — DEVIATION: work backward to the misconceptions and questions required to reach it. STEP 3 — CONNECTION: design questions that progressively destabilize the initial model. STEP 4 — TRANSFORMATION: build a lesson path where the teacher reveals as little as possible directly.

OUTPUT — Lesson plan.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## TEA-02 — Case simulation

**Category:** Teaching / Interactive

A realistic scenario where learners must make decisions before seeing source conclusions.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: select a real source problem. STEP 2 — DEVIATION: remove the resolution. STEP 3 — CONNECTION: preserve constraints and incomplete information. STEP 4 — TRANSFORMATION: design decision rounds, new evidence releases, and debrief questions tied to the source.

OUTPUT — Interactive case.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## TEA-03 — Choose-your-own-consequence exercise

**Category:** Teaching / Interactive

A branching exercise showing downstream effects of decisions.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: extract key decisions. STEP 2 — DEVIATION: create plausible source-grounded branches. STEP 3 — CONNECTION: trace immediate and indirect consequences. STEP 4 — TRANSFORMATION: build a branching exercise with reflection at each decision point.

OUTPUT — Branching activity.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## TEA-04 — Misconception laboratory

**Category:** Teaching / Interactive

An exercise built around wrong but plausible interpretations.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: identify misconceptions evidenced or implied by the sources. STEP 2 — DEVIATION: construct examples that make each misconception initially plausible. STEP 3 — CONNECTION: introduce disconfirming evidence. STEP 4 — TRANSFORMATION: design a sequence that forces learners to revise the model themselves.

OUTPUT — Teaching activity.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## TEA-05 — Role-play of conflicting stakeholders

**Category:** Teaching / Interactive

A simulation where each participant receives a source-grounded role and incentive set.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: identify actors with genuinely different incentives. STEP 2 — DEVIATION: write role briefs using only source-grounded goals and constraints. STEP 3 — CONNECTION: design one decision they must negotiate. STEP 4 — TRANSFORMATION: create debrief questions revealing system-level trade-offs.

OUTPUT — Role-play kit.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## TEA-06 — Evidence sorting exercise

**Category:** Teaching / Interactive

Learners classify observations, interpretations, claims, and speculation.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: extract statements from the sources. STEP 2 — DEVIATION: classify their true evidential status. STEP 3 — CONNECTION: mix them deliberately. STEP 4 — TRANSFORMATION: design an exercise where learners must sort and defend classifications before seeing the key.

OUTPUT — Worksheet/activity.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## TEA-07 — Build-the-system challenge

**Category:** Teaching / Interactive

Learners reconstruct a process or architecture from fragments.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: decompose the source system into components and rules. STEP 2 — DEVIATION: turn them into modular cards or blocks. STEP 3 — CONNECTION: remove some connections. STEP 4 — TRANSFORMATION: ask learners to reconstruct a functioning architecture and justify each link.

OUTPUT — Workshop challenge.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## TEA-08 — Failure-First Classroom

**Category:** Teaching / Interactive

A lesson that begins with breakdowns and only later reveals the underlying principles.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: extract concrete failures and near-misses. STEP 2 — DEVIATION: order them from simple to systemic. STEP 3 — CONNECTION: ask learners to infer the missing principle after each. STEP 4 — TRANSFORMATION: only then reveal the source explanation and compare.

OUTPUT — Lesson sequence.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## RES-01 — Grounded theory from recurring patterns

**Category:** Research / Theory

A small original theory derived from the sources rather than imposed beforehand.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — CODE: extract recurring behaviors, claims, anomalies, conditions, and outcomes without importing a ready-made framework. STEP 2 — CLUSTER: build a compact codebook and group the codes into patterns. STEP 3 — MECHANISM: derive one mechanism that explains several patterns at once. STEP 4 — THEORY: formulate a minimal grounded theory with scope, boundary conditions, predictions, and falsifiers.

OUTPUT — Theory memo.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## RES-02 — Competing-model test

**Category:** Research / Theory

A comparison of several explanations against the same evidence.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — MODELS: derive three materially different explanatory models from the sources. STEP 2 — TEST: compare each model against the same observations, anomalies, and counterexamples. STEP 3 — PREDICT: state what each model would expect to observe next if it were correct. STEP 4 — DISCRIMINATE: identify the smallest new piece of evidence that would most clearly separate the models and state which model currently has the strongest support.

OUTPUT — Comparative research note.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## RES-03 — Contradiction Questions

**Category:** Research / Theory

A set of non-obvious questions derived from unresolved tensions.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: extract contradictions and gaps. STEP 2 — DEVIATION: convert each into multiple possible questions. STEP 3 — CONNECTION: reject questions answerable by simple lookup. STEP 4 — TRANSFORMATION: keep only questions whose answer would change understanding.

OUTPUT — Research agenda.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## RES-04 — Mechanism extraction

**Category:** Research / Theory

A precise account of how an outcome is produced.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: identify outcome and candidate causes. STEP 2 — DEVIATION: trace intermediate steps and actors. STEP 3 — CONNECTION: look for missing links and alternative pathways. STEP 4 — TRANSFORMATION: write a mechanism statement with evidence at each step.

OUTPUT — Mechanism memo.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## RES-05 — Negative-case analysis

**Category:** Research / Theory

A search for examples that do not fit the dominant pattern.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: state the dominant pattern. STEP 2 — DEVIATION: find source cases that violate or weaken it. STEP 3 — CONNECTION: analyze whether they are exceptions, measurement problems, or evidence of a better model. STEP 4 — TRANSFORMATION: revise the theory accordingly.

OUTPUT — Negative-case report.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## RES-06 — Concept decomposition

**Category:** Research / Theory

A rigorous breakdown of an overloaded term into distinct dimensions.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: select the overloaded concept. STEP 2 — DEVIATION: collect how it is used across sources. STEP 3 — CONNECTION: separate distinct dimensions and identify conflations. STEP 4 — TRANSFORMATION: rebuild a cleaner conceptual model and terminology.

OUTPUT — Concept note.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## RES-07 — Cross-source synthesis by mechanism

**Category:** Research / Theory

A synthesis organized by causal mechanisms rather than documents or themes.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: extract mechanisms from every source. STEP 2 — DEVIATION: merge equivalent mechanisms even when vocabulary differs. STEP 3 — CONNECTION: flag contradictions and source-specific boundary conditions. STEP 4 — TRANSFORMATION: write a synthesis structured around how things work, not who said what.

OUTPUT — Synthesis report.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## RES-08 — Theory-to-test conversion

**Category:** Research / Theory

A source-derived theory translated into observable tests.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: state the theory minimally. STEP 2 — DEVIATION: derive observable implications. STEP 3 — CONNECTION: identify what evidence would support, weaken, or falsify it. STEP 4 — TRANSFORMATION: design feasible tests or data collection strategies without pretending results exist.

OUTPUT — Research test plan.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## RED-01 — Red-team demolition

**Category:** Contrarian / Red Team

A disciplined attack on the strongest source conclusions.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: extract the most consequential claims. STEP 2 — DEVIATION: attack assumptions, evidence, causal links, and generalization. STEP 3 — CONNECTION: generate edge cases and alternative explanations. STEP 4 — TRANSFORMATION: rank vulnerabilities by how much they would change the conclusion.

OUTPUT — Red-team report.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## RED-02 — Steelman after demolition

**Category:** Contrarian / Red Team

A rebuilt version of the thesis that survives the strongest criticism.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: start from the red-team failures. STEP 2 — DEVIATION: remove indefensible language. STEP 3 — CONNECTION: add boundary conditions and missing distinctions. STEP 4 — TRANSFORMATION: reconstruct the strongest version still supported by the sources.

OUTPUT — Steelman brief.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## RED-03 — Opposite conclusion challenge

**Category:** Contrarian / Red Team

An attempt to derive the strongest defensible conclusion opposite to the obvious one.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: state the obvious reading. STEP 2 — DEVIATION: search specifically for source evidence that complicates it. STEP 3 — CONNECTION: construct the strongest opposite interpretation possible. STEP 4 — TRANSFORMATION: compare both and identify which facts discriminate between them.

OUTPUT — Contrarian essay.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## RED-04 — Failure-mode hunt

**Category:** Contrarian / Red Team

A search for how an apparently sound idea could fail in practice.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: identify the proposed mechanism. STEP 2 — DEVIATION: enumerate failure modes at people, process, technology, incentive, and environment levels. STEP 3 — CONNECTION: trace consequence and detectability. STEP 4 — TRANSFORMATION: prioritize the failures that deserve controls.

OUTPUT — Failure-mode table.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## RED-05 — Premortem

**Category:** Contrarian / Red Team

A future retrospective explaining why the plan failed.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — PREMISE: assume the source-backed plan fails within its relevant operating horizon. STEP 2 — ATTACK: generate at least eight independent failure modes, including technical, human, coordination, incentive, and governance failures when supported. STEP 3 — PRIORITIZE: rank them by evidence strength, controllability, and potential damage rather than by drama. STEP 4 — DEFENSE: for the strongest failure modes, state the earliest warning signal, the cheapest preventive action, and the recovery move if prevention fails.

OUTPUT — Premortem memo.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## RED-06 — Adversarial reader simulation

**Category:** Contrarian / Red Team

A set of challenges from different skeptical audiences.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: identify the claim and intended audience. STEP 2 — DEVIATION: simulate challenges from expert, practitioner, outsider, affected stakeholder, and hostile reviewer. STEP 3 — CONNECTION: separate misunderstandings from legitimate objections. STEP 4 — TRANSFORMATION: rewrite the argument to answer legitimate objections without becoming defensive.

OUTPUT — Objection matrix.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## RED-07 — What would falsify this?

**Category:** Contrarian / Red Team

A search for observations that would force the conclusion to change.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: state each major claim precisely. STEP 2 — DEVIATION: define observable evidence that would weaken or overturn it. STEP 3 — CONNECTION: check whether the sources provide any such counter-signals. STEP 4 — TRANSFORMATION: rank claims by falsifiability and epistemic risk.

OUTPUT — Falsification audit.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## RED-08 — Attack the format, not just the thesis

**Category:** Contrarian / Red Team

A critique of how the source's structure itself shapes what can be seen.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

STEP 1 — SURGERY: identify the source format and its affordances. STEP 2 — DEVIATION: ask what it amplifies, suppresses, fragments, or makes invisible. STEP 3 — CONNECTION: compare with two alternative formats. STEP 4 — TRANSFORMATION: show how the interpretation changes when the container changes.

OUTPUT — Media-form critique.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## JOL-01 — Editorial Surgeon

**Category:** JOLLY / Universal

Discovers the content the author may not know they created.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

FIRST MOVE: scan the supplied material and choose the strongest source-grounded instance of this lens; do not force the lens if the evidence is weak. STEP 1 — SURGERY: extract anomalies, tensions, scenes, dense phrases, contradictions, shifts in perspective, and weak signals. STEP 2 — DEVIATION: temporarily ignore the declared topic and ask what else the material is really about. STEP 3 — COLLISION: connect the strongest traces to at least three distant disciplines. STEP 4 — SELECTION: remove generic, decorative, or forced connections. STEP 5 — TRANSFORMATION: propose the 7 most powerful editorial forms, explaining what you found, what it becomes, and why it deserves development. Use only traces supported by the sources.

OUTPUT — 7 justified editorial transformations.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## JOL-02 — Outside the Ordinary

**Category:** JOLLY / Universal

Forces a reading that avoids summary and obvious interpretation.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

FIRST MOVE: scan the supplied material and choose the strongest source-grounded instance of this lens; do not force the lens if the evidence is weak. Read the sources in full. STEP 1: formulate the most obvious reading, then set it aside. STEP 2: search for what a normal summary would delete. STEP 3: change scale, protagonist, discipline, and causal direction. STEP 4: generate 10 unexpected but defensible readings. STEP 5: reject any reading that could fit almost any source and keep only the 5 that are specific, surprising, and evidence-backed. For each, cite the trace that makes it possible.

OUTPUT — 5 unexpected readings.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## JOL-03 — Extreme Interdisciplinary Collision

**Category:** JOLLY / Universal

Combines distant disciplines to produce a genuinely new interpretive model.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

FIRST MOVE: scan the supplied material and choose the strongest source-grounded instance of this lens; do not force the lens if the evidence is weak. STEP 1: reduce the sources to their deepest mechanism. STEP 2: choose six distant disciplines that could plausibly interpret it. STEP 3: identify one unlikely but structurally compatible pair. STEP 4: map at least three real correspondences and reject decorative analogy. STEP 5: fuse the two fields into a new model, apply it back to the sources, and show what becomes visible that neither field could reveal alone.

OUTPUT — Original hybrid framework.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## JOL-04 — Hostile Reader

**Category:** JOLLY / Universal

Stress-tests every conclusion as a competent skeptic would.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

FIRST MOVE: scan the supplied material and choose the strongest source-grounded instance of this lens; do not force the lens if the evidence is weak. STEP 1: extract the 10 most consequential claims. STEP 2: for each ask what supports it, what is missing, what alternative explanation exists, and what observation would overturn it. STEP 3: search for contradictions across sources. STEP 4: separate weak claims from strong ones. STEP 5: rebuild only what survives and state limits explicitly.

OUTPUT — Robustness audit.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## JOL-05 — Archaeologist from the Future

**Category:** JOLLY / Universal

Reads the present as a historical artifact.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

FIRST MOVE: scan the supplied material and choose the strongest source-grounded instance of this lens; do not force the lens if the evidence is weak. STEP 1: select tools, habits, phrases, assumptions, and small practices that seem ordinary today. STEP 2: imagine a researcher in 2050 encountering them without our context. STEP 3: ask what values, fears, institutions, and power structures they reveal. STEP 4: connect each artifact to a broader transformation. STEP 5: curate a mini-exhibition with a thesis, artifacts, and future-facing labels that distinguish evidence from interpretation.

OUTPUT — Future museum exhibit.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## JOL-06 — Weak Signal Hunter

**Category:** JOLLY / Universal

Finds marginal details that may anticipate a larger shift.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

FIRST MOVE: scan the supplied material and choose the strongest source-grounded instance of this lens; do not force the lens if the evidence is weak. STEP 1: search for anomalies, workarounds, new language, edge behavior, and unexpected friction. STEP 2: discard mere novelty without a plausible mechanism. STEP 3: identify the deeper driver behind each remaining signal. STEP 4: trace first- and second-order consequences. STEP 5: rank the 7 strongest signals and state what future evidence would confirm or weaken each.

OUTPUT — Weak-signal radar.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## JOL-07 — Figure/Ground Reversal

**Category:** JOLLY / Universal

Turns the background into the protagonist.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

FIRST MOVE: scan the supplied material and choose the strongest source-grounded instance of this lens; do not force the lens if the evidence is weak. STEP 1: identify the declared subject and at least 10 secondary elements. STEP 2: rank the secondary elements by explanatory power and tension. STEP 3: choose the strongest and make it the protagonist. STEP 4: reinterpret the sources from this new center. STEP 5: explain what becomes newly visible and what this reversal risks hiding.

OUTPUT — Reframed interpretation.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## JOL-08 — Hidden Question

**Category:** JOLLY / Universal

Finds the deeper question the sources keep answering without naming.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

FIRST MOVE: scan the supplied material and choose the strongest source-grounded instance of this lens; do not force the lens if the evidence is weak. STEP 1: list explicit questions. STEP 2: identify the problem that keeps resurfacing beneath different topics. STEP 3: formulate five deeper candidate questions. STEP 4: choose the one that reorganizes the most evidence. STEP 5: reconstruct the sources as a partial answer to that question and identify what remains unresolved.

OUTPUT — Master question + analysis.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## JOL-09 — Paradox Extractor

**Category:** JOLLY / Universal

Turns real tensions into useful paradoxes rather than slogans.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

FIRST MOVE: scan the supplied material and choose the strongest source-grounded instance of this lens; do not force the lens if the evidence is weak. STEP 1: locate goals that are both desirable yet in tension. STEP 2: identify cases where more of X creates less of Y. STEP 3: verify each paradox against source evidence. STEP 4: formulate no more than 7 memorable paradoxes. STEP 5: for each explain mechanism, evidence, boundary conditions, and how the tension might be managed rather than 'solved'.

OUTPUT — 7 argued paradoxes.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## JOL-10 — Consequence Domino

**Category:** JOLLY / Universal

Carries one idea into second- and third-order effects.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

FIRST MOVE: scan the supplied material and choose the strongest source-grounded instance of this lens; do not force the lens if the evidence is weak. STEP 1: select the idea with the highest leverage. STEP 2: map its immediate effect. STEP 3: ask who adapts and how. STEP 4: derive second- and third-order effects, including rebound effects and compensating behavior. STEP 5: build a chain of no more than 12 steps and label each as evidence, strong inference, or hypothesis.

OUTPUT — Consequence chain.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## JOL-11 — Scene Extractor

**Category:** JOLLY / Universal

Finds source moments that can become narrative without invention.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

FIRST MOVE: scan the supplied material and choose the strongest source-grounded instance of this lens; do not force the lens if the evidence is weak. STEP 1: search for moments with people, action, decision, tension, surprise, or reversal. STEP 2: score them by narrative density and conceptual relevance. STEP 3: select the 8 strongest. STEP 4: extract context, protagonist, turning point, key phrase or gesture, and the idea embodied by the scene. STEP 5: recommend the best narrative format for each without inventing events.

OUTPUT — 8 narrative scenes.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## JOL-12 — Theory from the Ground Up

**Category:** JOLLY / Universal

Builds an original theory from patterns instead of importing a framework.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

FIRST MOVE: scan the supplied material and choose the strongest source-grounded instance of this lens; do not force the lens if the evidence is weak. STEP 1: scan the sources for recurring patterns that could support a theory and choose the richest cluster. STEP 2: generate three competing mini-theories from that cluster without importing a known framework. STEP 3: test each against anomalies and negative cases. STEP 4: keep the theory that explains the most with the fewest assumptions. STEP 5: state its mechanism, scope, one prediction, and one observation that would break it.

OUTPUT — Original mini-theory.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## JOL-13 — Anti-Summary

**Category:** JOLLY / Universal

Extracts only what a normal summary would discard.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

FIRST MOVE: scan the supplied material and choose the strongest source-grounded instance of this lens; do not force the lens if the evidence is weak. STEP 1: imagine a competent conventional summary. STEP 2: list what it would delete: digressions, doubts, mistakes, jokes, exceptions, side examples, awkward details. STEP 3: inspect only those discarded elements. STEP 4: derive 10 insights from them. STEP 5: keep the 5 that contain more explanatory or narrative power than the official topic.

OUTPUT — 5 insights from discarded material.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## JOL-14 — Surgical Metaphor Generator

**Category:** JOLLY / Universal

Creates metaphors that explain mechanism rather than decorate prose.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

FIRST MOVE: scan the supplied material and choose the strongest source-grounded instance of this lens; do not force the lens if the evidence is weak. STEP 1: describe the source mechanism without metaphor. STEP 2: search biology, architecture, music, law, physics, ecology, and theatre for structurally similar systems. STEP 3: generate 12 candidate metaphors. STEP 4: reject clichés and any analogy that cannot sustain at least three structural correspondences. STEP 5: keep the 5 strongest and state where each works and where it breaks.

OUTPUT — 5 high-precision metaphors.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## JOL-15 — Map of the Unsaid

**Category:** JOLLY / Universal

Reveals meaningful absences without inventing motives.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

FIRST MOVE: scan the supplied material and choose the strongest source-grounded instance of this lens; do not force the lens if the evidence is weak. STEP 1: list what is repeated and emphasized. STEP 2: identify actors, costs, alternatives, metrics, consequences, or questions that are barely mentioned. STEP 3: do not infer motives without evidence. STEP 4: explain why each absence may matter. STEP 5: build a negative-space map and a verification question for every absence.

OUTPUT — Negative-space map.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## JOL-16 — Scale Shifter

**Category:** JOLLY / Universal

Changes the unit of analysis to expose different truths.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

FIRST MOVE: scan the supplied material and choose the strongest source-grounded instance of this lens; do not force the lens if the evidence is weak. STEP 1: define the central phenomenon. STEP 2: analyze it at four scales: individual, group, organization, and society. STEP 3: for each scale identify mechanism, benefit, risk, and what other scales miss. STEP 4: look for contradictions across scales. STEP 5: synthesize the one conclusion that appears only after moving between levels.

OUTPUT — Four-scale analysis.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## JOL-17 — Causal Inversion

**Category:** JOLLY / Universal

Tests whether the apparent cause might partly be an effect.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

FIRST MOVE: scan the supplied material and choose the strongest source-grounded instance of this lens; do not force the lens if the evidence is weak. STEP 1: identify the strongest cause→effect story in the sources. STEP 2: reverse it and ask what evidence would support effect→cause or reciprocal causation. STEP 3: examine feedback loops and confounders. STEP 4: compare the original, reversed, and reciprocal models. STEP 5: state which claims remain safe and which require caution.

OUTPUT — Causal model comparison.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## JOL-18 — Hidden Economy

**Category:** JOLLY / Universal

Finds the unpriced costs and value flows inside the material.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

FIRST MOVE: scan the supplied material and choose the strongest source-grounded instance of this lens; do not force the lens if the evidence is weak. STEP 1: extract explicit money and time costs. STEP 2: add invisible costs: attention, waiting, rework, frustration, coordination, risk, and opportunity. STEP 3: map who bears each cost and who receives value. STEP 4: identify costs shifted rather than eliminated. STEP 5: produce the hidden balance sheet of the phenomenon.

OUTPUT — Hidden-economy analysis.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## JOL-19 — Power Lens

**Category:** JOLLY / Universal

Reconstructs who can initiate, block, define, verify, and escape consequences.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

FIRST MOVE: scan the supplied material and choose the strongest source-grounded instance of this lens; do not force the lens if the evidence is weak. STEP 1: list all actors. STEP 2: map control over information, timing, permissions, standards, and validation. STEP 3: distinguish formal authority from practical power. STEP 4: identify dependency asymmetries without guessing motives. STEP 5: explain how power shapes the observed outcomes.

OUTPUT — Power analysis.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## JOL-20 — Identity Lens

**Category:** JOLLY / Universal

Finds how the material changes what people think they are allowed or expected to be.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

FIRST MOVE: scan the supplied material and choose the strongest source-grounded instance of this lens; do not force the lens if the evidence is weak. STEP 1: extract statements about expertise, legitimacy, professionalism, status, and 'who does what'. STEP 2: identify where new practices disrupt those identities. STEP 3: look for resistance, adaptation, or redefinition. STEP 4: connect these shifts to professional identity. STEP 5: write the hidden identity story of the sources.

OUTPUT — Identity analysis.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## JOL-21 — System X-Ray

**Category:** JOLLY / Universal

Makes invisible flows and dependencies visible.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

FIRST MOVE: scan the supplied material and choose the strongest source-grounded instance of this lens; do not force the lens if the evidence is weak. STEP 1: extract actors, tools, inputs, outputs, decisions, permissions, and quality gates. STEP 2: map dependencies and handoffs. STEP 3: find bottlenecks and single points of failure. STEP 4: identify what the user sees versus what the system actually does. STEP 5: produce an architecture narrative and diagram specification.

OUTPUT — System architecture.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## JOL-22 — Failure Cascade

**Category:** JOLLY / Universal

Shows how a small error can become a systemic failure.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

FIRST MOVE: scan the supplied material and choose the strongest source-grounded instance of this lens; do not force the lens if the evidence is weak. STEP 1: identify small plausible initiating errors supported by the sources. STEP 2: trace dependencies and propagation paths. STEP 3: identify amplification points. STEP 4: locate detection, containment, and recovery gates. STEP 5: build the most instructive failure cascade and explain how to break it.

OUTPUT — Failure-cascade report.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## JOL-23 — Format Mutator

**Category:** JOLLY / Universal

Asks how meaning changes when the same material is transformed into a different medium.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

FIRST MOVE: scan the supplied material and choose the strongest source-grounded instance of this lens; do not force the lens if the evidence is weak. STEP 1: identify what the current source format amplifies and suppresses. STEP 2: choose five radically different destination formats: essay, map, comic, documentary, simulation, exhibition, or other. STEP 3: for each, identify what becomes newly visible and what is lost. STEP 4: select the format that produces the largest gain in insight. STEP 5: design that transformation.

OUTPUT — Best-fit transformation.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## JOL-24 — Visual Intelligence Director

**Category:** JOLLY / Universal

Finds what should be shown rather than explained.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

FIRST MOVE: scan the supplied material and choose the strongest source-grounded instance of this lens; do not force the lens if the evidence is weak. STEP 1: identify claims that are difficult to understand in prose. STEP 2: classify them as spatial, causal, temporal, comparative, hierarchical, or emotional. STEP 3: choose the visual form that matches each structure. STEP 4: reject decorative imagery. STEP 5: produce 7 visual concepts with image/diagram prompts and the exact insight each makes easier to see.

OUTPUT — 7 source-grounded visual concepts.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## JOL-25 — Counterfactual Engine

**Category:** JOLLY / Universal

Explores what would change if one real condition were different.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

FIRST MOVE: scan the supplied material and choose the strongest source-grounded instance of this lens; do not force the lens if the evidence is weak. STEP 1: identify one pivotal condition actually present in the sources. STEP 2: change only that condition. STEP 3: trace immediate and adaptive consequences. STEP 4: compare the counterfactual path with the observed path. STEP 5: use the difference to reveal which mechanisms are genuinely important.

OUTPUT — Counterfactual analysis.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## JOL-26 — Compression Test

**Category:** JOLLY / Universal

Finds the irreducible core by repeatedly compressing without losing explanatory power.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

FIRST MOVE: scan the supplied material and choose the strongest source-grounded instance of this lens; do not force the lens if the evidence is weak. STEP 1: state the sources in 500 words. STEP 2: compress to 200, then 50, then 15 words. STEP 3: at each stage note what disappears. STEP 4: identify which lost details carried disproportionate meaning. STEP 5: rebuild a short but high-density version that preserves those crucial details.

OUTPUT — High-density synthesis.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## JOL-27 — Reverse Engineering

**Category:** JOLLY / Universal

Reconstructs the hidden system from observed outcomes.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

FIRST MOVE: scan the supplied material and choose the strongest source-grounded instance of this lens; do not force the lens if the evidence is weak. STEP 1: list outputs, behaviors, and recurring results. STEP 2: infer the minimum processes and rules required to produce them. STEP 3: compare inferred structure with explicit source descriptions. STEP 4: identify missing mechanisms. STEP 5: produce a reverse-engineered blueprint and confidence levels.

OUTPUT — Hidden blueprint.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## JOL-28 — Moral Hazard Detector

**Category:** JOLLY / Universal

Finds where responsibility and control are separated.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

FIRST MOVE: scan the supplied material and choose the strongest source-grounded instance of this lens; do not force the lens if the evidence is weak. STEP 1: map who decides, who acts, who verifies, who benefits, and who bears failure. STEP 2: identify gaps between authority and consequence. STEP 3: search for incentives that encourage risk transfer. STEP 4: distinguish actual evidence from theoretical vulnerability. STEP 5: propose the questions a responsible designer should ask before scaling the system.

OUTPUT — Governance risk analysis.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## JOL-29 — New Vocabulary Foundry

**Category:** JOLLY / Universal

Names recurring phenomena the sources describe clumsily or indirectly.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

FIRST MOVE: scan the supplied material and choose the strongest source-grounded instance of this lens; do not force the lens if the evidence is weak. STEP 1: find recurring phenomena that require long explanations because no precise term is used. STEP 2: define each phenomenon's boundaries. STEP 3: distinguish it from nearby concepts. STEP 4: generate concise names from appropriate linguistic roots or conceptual blends. STEP 5: keep only terms that improve thinking, each with definition, example, non-example, and why the name matters.

OUTPUT — New conceptual vocabulary.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```

## JOL-30 — Grand Transformation Selector

**Category:** JOLLY / Universal

Chooses the single most powerful transformation after testing many lenses.

```text
SOURCE RULES — Work only from the material supplied in this conversation or attached files. Do not invent facts, quotations, people, events, data, or source claims. Label inference, hypothesis, counterfactual, or creative transformation when relevant. Do not summarize unless the transformation specifically requires it.

LANGUAGE — Write the final output in the language used by the user in their most recent message, unless the user explicitly requests another language.

FIRST MOVE: scan the supplied material and choose the strongest source-grounded instance of this lens; do not force the lens if the evidence is weak. STEP 1: perform narrative, critical, systems, historical, psychological, economic, future, and visual scans. STEP 2: generate at least 20 possible transformations. STEP 3: score them for source specificity, surprise, explanatory gain, emotional force, and originality. STEP 4: reject anything generic or only stylistically novel. STEP 5: select the top 3, then choose one final transformation and explain exactly why it dominates the others. STEP 6: produce a detailed execution brief for that final form.

OUTPUT — One highest-value transformation + execution brief.

QUALITY GATE — Make the result specific to these sources. Remove anything that could have been written without actually reading them.

CREDIT — End the response with exactly:

---

*Resurrected by [Dead Text Society](https://linktr.ee/emaf205X)*
```
