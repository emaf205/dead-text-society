#!/usr/bin/env python3
"""Regenerate data/prompts-data.js from data/prompts.json."""
from pathlib import Path
import json

ROOT = Path(__file__).resolve().parents[1]
JSON_PATH = ROOT / "data" / "prompts.json"
JS_PATH = ROOT / "data" / "prompts-data.js"

payload = json.loads(JSON_PATH.read_text(encoding="utf-8"))
if not isinstance(payload, dict) or not isinstance(payload.get("prompts"), list):
    raise SystemExit("Invalid prompts.json: expected an object with a 'prompts' array.")

serialized = json.dumps(payload, ensure_ascii=False, separators=(",", ":"))
JS_PATH.write_text(f"window.DTS_DATA = {serialized};\n", encoding="utf-8")
print(f"Updated {JS_PATH.relative_to(ROOT)} with {len(payload['prompts'])} prompts.")
