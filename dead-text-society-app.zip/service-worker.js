const CACHE_PREFIX = 'dead-text-society-';
const CACHE = `${CACHE_PREFIX}${self.registration.scope}-v1.8-fixes-2`;
const CORE = [
  './','./index.html','./styles.css','./app.js','./config.js','./data/prompts-data.js','./locales.js',
  './assets/paper.webp','./assets/black.webp','./assets/hero.webp','./assets/pattern.webp','./assets/waves.webp','./assets/burst.webp','./assets/skull.webp','./assets/skull-card.webp','./assets/ruins.webp',
  './icons/favicon-32.png','./icons/apple-touch-icon.png','./icons/icon-192.png','./icons/icon-512.png','./icons/icon-maskable-512.png','./manifest.webmanifest',
  './data/prompts.json','./downloads/Dead_Text_Society_Prompt_Master_EN.xlsx','./downloads/dead-text-society-vault.md'
];
self.addEventListener('install',event=>event.waitUntil(caches.open(CACHE).then(async cache=>{await cache.addAll(CORE);try{await cache.add('./downloads/dead-text-society-app.zip');}catch{/* Extracted packages do not contain their own ZIP. */}}).then(()=>self.skipWaiting())));
self.addEventListener('activate',event=>event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k.startsWith(`${CACHE_PREFIX}${self.registration.scope}-`)&&k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',event=>{
  const url=new URL(event.request.url);
  if(event.request.method!=='GET'||url.origin!==self.location.origin||!url.href.startsWith(self.registration.scope))return;
  event.respondWith((async()=>{
    const cache=await caches.open(CACHE);
    const cached=await cache.match(event.request);
    if(cached)return cached;
    try{
      const response=await fetch(event.request);
      if(response.ok){
        try{await cache.put(event.request,response.clone());}catch{/* Storage may be full. */}
      }
      return response;
    }catch{
      return event.request.mode==='navigate' ? (await cache.match('./index.html')) || Response.error() : Response.error();
    }
  })());
});
