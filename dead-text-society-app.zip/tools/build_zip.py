#!/usr/bin/env python3
"""Build the downloadable app without nesting its own ZIP or development files."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
ROOT = Path(__file__).resolve().parents[1]
TARGET = ROOT / 'downloads/dead-text-society-app.zip'
FILES = ['index.html', 'app.js', 'config.js', 'locales.js', 'styles.css',
         'service-worker.js', 'manifest.webmanifest', 'README.md', 'LICENSE', '.nojekyll']
with ZipFile(TARGET, 'w', ZIP_DEFLATED) as archive:
    for name in FILES:
        archive.write(ROOT / name, name)
    for folder in ['assets', 'icons', 'data', 'downloads', 'tools']:
        for file in sorted((ROOT / folder).rglob('*')):
            if file.is_file() and file != TARGET and file.name != '.DS_Store' and '__pycache__' not in file.parts:
                archive.write(file, file.relative_to(ROOT))
print(f'Built {TARGET.relative_to(ROOT)}')
