window.DTS_CONFIG = Object.freeze({
  creatorName: "Emanuele BDC",
  creatorUrl: "https://linktr.ee/emaf205X",
  siteUrl: "",
  upsell: {
    enabled: false,
    title: "",
    url: ""
  }
});
